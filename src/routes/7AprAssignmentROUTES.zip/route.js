const express = require('express');
const router = express.Router();
// Problem 1
router.get('/movies', function (req, res) 
{
const Array =["Spiderman","Batman","Superman","Pk","3Idiots","Deadpol","War"];
    res.send(Array);
});
// Problem 2,3
router.get('/movies/:indexOfArray', function (req, res)
 {
    const Array =["Spiderman","Batman","Superman","Pk","3Idiots","Deadpol","War"];
    const index =req.params.indexOfArray;
    if(index < Array.length)
    {
      res.send(Array[index]);
    }
    else
     {
        res.send("Invalid Index,Please use Valid Index!");
     }
    });

// Problem 4
router.get('/films', function (req, res) 
{
     
    const Array =[{id:1,name:"Spiderman"},{id:2,name:"Batman"},
    {id:3,name:"Superman"},{id:4,name:"Pk"},{id:5,name:"3Idiots"},{id:6,name:"Deadpol"},{id:7,name:"War"}];
         
       res.send(Array);
});
      
// Problem 5
router.get('/films', function (req, res) 
{
function filenames()
{
    const Array =[{id:1,name:"Spiderman"},{id:2,name:"Batman"},
    {id:3,name:"Superman"},{id:4,name:"Pk"},{id:5,name:"3Idiots"},{id:6,name:"Deadpol"},{id:7,name:"War"}]; 
   for(let i=0;i<Array.length;i++)
   {  
       if(Array[i].id === Array.length)
        {}
        if(Array[i].id === req.params.filmId)
        return Array[i];
      else if(Array[i].id !== req.params.filmId)
        return "No movie exist with this id";
    }
 }   
   res.send(filenames());
});

module.exports = router;
